"""
cross_validation.py

Reproduces the manuscript's held-out radial cross-validation
(Section "Held-out radial cross-validation"): fit on inner/outer
radial half, predict the other half, for the three SPARC-overlap
galaxies plus WLM.

Run: python cross_validation.py
"""

import numpy as np
from data_loading import load_all, get_vbar2_any
from halo_models import fit_M0_pISO, fit_M1_pISO

GALAXIES_TO_TEST = ["DDO154", "DDO168", "NGC2366", "WLM"]


def run():
    loaded = load_all()
    print(f"{'Galaxy':10s} {'Fold':14s} {'RMSE M0':>10s} {'RMSE M1':>10s} {'Winner':>8s}")

    results = {}
    for g in GALAXIES_TO_TEST:
        lt = loaded["lt_data"][g]
        R, Vc, err = lt["R_kpc"], lt["Vc"], lt["err_Vc"]
        Vbar2 = get_vbar2_any(g, loaded)
        mid = len(R) // 2

        folds = [
            ("inner->outer", slice(0, mid), slice(mid, None)),
            ("outer->inner", slice(mid, None), slice(0, mid)),
        ]

        for label, train_idx, test_idx in folds:
            Rt, Vct, errt, Vbt = R[train_idx], Vc[train_idx], err[train_idx], Vbar2[train_idx]
            Rp, Vcp, Vbp = R[test_idx], Vc[test_idx], Vbar2[test_idx]

            popt0, _ = fit_M0_pISO(Rt, Vct, errt, Vbt)
            rho0, rc = popt0
            Vh2p = 4 * np.pi * 4.301e-6 * rho0 * rc**2 * (1 - (rc / Rp) * np.arctan(Rp / rc))
            Vpred0 = np.sqrt(np.clip(Vbp + Vh2p, 0, None))
            rmse0 = np.sqrt(np.mean((Vcp - Vpred0) ** 2))

            popt1, _ = fit_M1_pISO(Rt, Vct, errt, Vbt, rho0, rc)
            rho0m, rcm, A, Rstar = popt1
            Vh2p_m = 4 * np.pi * 4.301e-6 * rho0m * rcm**2 * (1 - (rcm / Rp) * np.arctan(Rp / rcm))
            qp = np.clip(1 - A * np.exp(-Rstar / np.maximum(Rp, 1e-3)), 0, 1)
            Vpred1 = np.sqrt(np.clip(Vbp + qp * Vh2p_m, 0, None))
            rmse1 = np.sqrt(np.mean((Vcp - Vpred1) ** 2))

            winner = "M0" if rmse0 < rmse1 else "M1"
            results[(g, label)] = dict(rmse0=rmse0, rmse1=rmse1, winner=winner)
            print(f"{g:10s} {label:14s} {rmse0:10.3f} {rmse1:10.3f} {winner:>8s}")

    return results


if __name__ == "__main__":
    run()
