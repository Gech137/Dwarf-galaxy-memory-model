"""
bootstrap_analysis.py

Reproduces the manuscript's dual bootstrap analysis (Section
"Bootstrap assessment"): a residual bootstrap (null distribution --
how large would dAIC look under pure noise if M0 were exactly
correct) and a case-resampling bootstrap (sampling uncertainty on the
actually observed dAIC), for all ten galaxies under the
pseudo-isothermal halo.

Run: python bootstrap_analysis.py
"""

import numpy as np
from data_loading import load_all, get_vbar2_any, TARGET_GALAXIES
from halo_models import fit_M0_pISO, fit_M1_pISO, aic

N_BOOT_RESIDUAL = 200
N_BOOT_CASE = 150


def _dAIC_for(R, Vc, err, Vbar2):
    popt0, _ = fit_M0_pISO(R, Vc, err, Vbar2)
    rho0, rc = popt0
    Vh2 = 4 * np.pi * 4.301e-6 * rho0 * rc**2 * (1 - (rc / R) * np.arctan(R / rc))
    Vfit0 = np.sqrt(np.clip(Vbar2 + Vh2, 0, None))
    chi2_0 = np.sum(((Vc - Vfit0) / err) ** 2)

    popt1, _ = fit_M1_pISO(R, Vc, err, Vbar2, rho0, rc)
    rho0m, rcm, A, Rstar = popt1
    Vh2m = 4 * np.pi * 4.301e-6 * rho0m * rcm**2 * (1 - (rcm / R) * np.arctan(R / rcm))
    qm = np.clip(1 - A * np.exp(-Rstar / np.maximum(R, 1e-3)), 0, 1)
    Vfit1 = np.sqrt(np.clip(Vbar2 + qm * Vh2m, 0, None))
    chi2_1 = np.sum(((Vc - Vfit1) / err) ** 2)
    chi2_1 = min(chi2_1, chi2_0)

    return aic(chi2_0, 2) - aic(chi2_1, 4), popt0, Vfit0


def residual_bootstrap(R, Vc, err, Vbar2, n_boot=N_BOOT_RESIDUAL, seed=42):
    """Null-distribution test: assumes M0 exactly correct, resamples
    residuals, refits both models each time."""
    rng = np.random.default_rng(seed)
    _, popt0, Vfit0 = _dAIC_for(R, Vc, err, Vbar2)
    resid0 = Vc - Vfit0

    dAICs = []
    for _ in range(n_boot):
        boot_resid = rng.choice(resid0, size=len(resid0), replace=True)
        Vc_boot = Vfit0 + boot_resid
        try:
            dA, _, _ = _dAIC_for(R, Vc_boot, err, Vbar2)
            dAICs.append(dA)
        except Exception:
            continue
    return np.array(dAICs)


def case_bootstrap(R, Vc, err, Vbar2, n_boot=N_BOOT_CASE, seed=1):
    """Sampling-uncertainty estimate: resample (R, Vc, err, Vbar2)
    tuples with replacement, refit both models each time."""
    rng = np.random.default_rng(seed)
    n = len(R)
    dAICs = []
    for _ in range(n_boot):
        idx = rng.choice(n, size=n, replace=True)
        if len(np.unique(R[idx])) < 4:
            continue
        try:
            dA, _, _ = _dAIC_for(R[idx], Vc[idx], err[idx], Vbar2[idx])
            dAICs.append(dA)
        except Exception:
            continue
    return np.array(dAICs)


def run():
    loaded = load_all()
    results = {}
    for g in TARGET_GALAXIES:
        lt = loaded["lt_data"][g]
        R, Vc, err = lt["R_kpc"], lt["Vc"], lt["err_Vc"]
        Vbar2 = get_vbar2_any(g, loaded)

        resid_dAICs = residual_bootstrap(R, Vc, err, Vbar2)
        case_dAICs = case_bootstrap(R, Vc, err, Vbar2)

        results[g] = dict(residual=resid_dAICs, case=case_dAICs)
        print(f"{g:10s} residual: median={np.median(resid_dAICs):+.2f} "
              f"frac(>4)={np.mean(resid_dAICs > 4):.2f}   |   "
              f"case: median={np.median(case_dAICs):+.2f} "
              f"[{np.percentile(case_dAICs,16):+.2f}, {np.percentile(case_dAICs,84):+.2f}]")

    return results


if __name__ == "__main__":
    run()
