"""
aic_comparison.py

Reproduces the manuscript's main M0-vs-M1 AIC comparison table, for
all ten galaxies, under both the pseudo-isothermal and NFW halo
families (manuscript Section "Equilibrium versus memory model: full
test" and Table "AIC comparison").

Run: python aic_comparison.py
"""

import numpy as np
from data_loading import load_all, get_vbar2_any, TARGET_GALAXIES
from halo_models import (fit_M0_pISO, fit_M1_pISO, fit_M0_NFW, fit_M1_NFW, aic)


def run():
    loaded = load_all()
    print(f"{'Galaxy':10s} {'dAIC_pISO':>10s} {'dAIC_NFW':>9s} {'Agree?':>7s}")

    results = {}
    for g in TARGET_GALAXIES:
        lt = loaded["lt_data"][g]
        R, Vc, err = lt["R_kpc"], lt["Vc"], lt["err_Vc"]
        Vbar2 = get_vbar2_any(g, loaded)

        # --- pseudo-isothermal ---
        popt0i, _ = fit_M0_pISO(R, Vc, err, Vbar2)
        chi2_0i = np.sum(((Vc - _model_val_pISO(R, popt0i, Vbar2, memory=False)) / err) ** 2)
        popt1i, _ = fit_M1_pISO(R, Vc, err, Vbar2, popt0i[0], popt0i[1])
        chi2_1i = np.sum(((Vc - _model_val_pISO(R, popt1i, Vbar2, memory=True)) / err) ** 2)
        chi2_1i = min(chi2_1i, chi2_0i)  # enforce nesting numerically
        dAIC_iso = aic(chi2_0i, 2) - aic(chi2_1i, 4)

        # --- NFW ---
        popt0n, _ = fit_M0_NFW(R, Vc, err, Vbar2)
        chi2_0n = np.sum(((Vc - _model_val_NFW(R, popt0n, Vbar2, memory=False)) / err) ** 2)
        popt1n, _ = fit_M1_NFW(R, Vc, err, Vbar2, popt0n[0], popt0n[1])
        chi2_1n = np.sum(((Vc - _model_val_NFW(R, popt1n, Vbar2, memory=True)) / err) ** 2)
        chi2_1n = min(chi2_1n, chi2_0n)
        dAIC_nfw = aic(chi2_0n, 2) - aic(chi2_1n, 4)

        agree = (dAIC_iso > 4) == (dAIC_nfw > 4)
        results[g] = dict(dAIC_iso=dAIC_iso, dAIC_nfw=dAIC_nfw, agree=agree)
        print(f"{g:10s} {dAIC_iso:10.2f} {dAIC_nfw:9.2f} {'YES' if agree else 'NO':>7s}")

    return results


# --- small helpers to evaluate the fitted models without re-closing over Vbar2 ---

def _model_val_pISO(R, popt, Vbar2, memory):
    if not memory:
        rho0, rc = popt
        Vh2 = 4 * np.pi * 4.301e-6 * rho0 * rc**2 * (1 - (rc / R) * np.arctan(R / rc))
        return np.sqrt(np.clip(Vbar2 + Vh2, 0, None))
    rho0, rc, A, Rstar = popt
    Vh2 = 4 * np.pi * 4.301e-6 * rho0 * rc**2 * (1 - (rc / R) * np.arctan(R / rc))
    q = np.clip(1 - A * np.exp(-Rstar / np.maximum(R, 1e-3)), 0, 1)
    return np.sqrt(np.clip(Vbar2 + q * Vh2, 0, None))


def _model_val_NFW(R, popt, Vbar2, memory):
    if not memory:
        rho_s, rs = popt
        x = R / rs
        Vh2 = (4 * np.pi * 4.301e-6 * rho_s * rs**3 / R) * (np.log(1 + x) - x / (1 + x))
        return np.sqrt(np.clip(Vbar2 + Vh2, 0, None))
    rho_s, rs, A, Rstar = popt
    x = R / rs
    Vh2 = (4 * np.pi * 4.301e-6 * rho_s * rs**3 / R) * (np.log(1 + x) - x / (1 + x))
    q = np.clip(1 - A * np.exp(-Rstar / np.maximum(R, 1e-3)), 0, 1)
    return np.sqrt(np.clip(Vbar2 + q * Vh2, 0, None))


if __name__ == "__main__":
    run()
