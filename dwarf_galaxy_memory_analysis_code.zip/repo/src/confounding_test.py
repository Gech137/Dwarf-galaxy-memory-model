"""
confounding_test.py

Reproduces the manuscript's radial-confounding result (Section
"Radial confounding: measured, not assumed"): raw vs. radius-partialled
Spearman correlation between the coherence variable C and the
dynamical timescale tau, for all ten target galaxies, using real
Iorio et al. (2017) kinematic data.

Run: python confounding_test.py
"""

import numpy as np
from scipy.stats import spearmanr, rankdata
from data_loading import load_all, TARGET_GALAXIES


def partial_spearman(x, y, control):
    """Spearman correlation of x and y after linearly regressing out
    their rank-dependence on `control` (here: radius)."""
    rx, ry, rc = rankdata(x), rankdata(y), rankdata(control)
    bx = np.polyfit(rc, rx, 1)
    by = np.polyfit(rc, ry, 1)
    resx = rx - np.polyval(bx, rc)
    resy = ry - np.polyval(by, rc)
    return spearmanr(resx, resy)


def run():
    loaded = load_all()
    print(f"{'Galaxy':10s} {'N':>3s} {'raw rho':>9s} {'raw p':>7s} "
          f"{'partial rho':>12s} {'partial p':>10s}")

    results = {}
    for g in TARGET_GALAXIES:
        lt = loaded["lt_data"][g]
        R = lt["R_kpc"]
        Vrot = lt["Vrot"]
        sigma_v = lt["sigma_v"]

        # Eq. 1 of the manuscript
        C = Vrot**2 / (Vrot**2 + sigma_v**2)

        # dynamical timescale proxy: 2*pi*R / Vc, converted kpc/(km/s) -> Gyr
        Vc = lt["Vc"]
        tau_char_Gyr = (2 * np.pi * R / Vc) * 0.9778

        rho_raw, p_raw = spearmanr(C, tau_char_Gyr)
        rho_partial, p_partial = partial_spearman(C, tau_char_Gyr, R)

        results[g] = dict(rho_raw=rho_raw, p_raw=p_raw,
                           rho_partial=rho_partial, p_partial=p_partial, N=len(R))
        print(f"{g:10s} {len(R):3d} {rho_raw:+9.3f} {p_raw:7.3f} "
              f"{rho_partial:+12.3f} {p_partial:10.3f}")

    return results


if __name__ == "__main__":
    run()
