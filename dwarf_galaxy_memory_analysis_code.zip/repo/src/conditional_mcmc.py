"""
conditional_mcmc.py

Reproduces the manuscript's converged 2D conditional posterior
(Section "Converged posterior: a 2D conditional analysis"): with the
pseudo-isothermal halo shape parameters FIXED at their deterministic
best-fit values, samples the full posterior over the memory
parameters (A, R_star) alone, for the three SPARC-overlap galaxies.

Note on the full 4-parameter joint posterior: an earlier attempt to
sample (rho0, rc, A, Rstar) jointly did NOT converge within a
practical compute budget -- see manuscript Section "Converged
posterior" for full discussion of why, and of the specific R_star
prior-boundary artifact encountered along the way. That unconverged
4-parameter version is NOT reproduced here as a "result"; only the
converged 2D conditional analysis is.

Requires: emcee (pip install emcee)

Run: python conditional_mcmc.py
"""

import numpy as np
from data_loading import load_all, get_vbar2_any, SPARC_OVERLAP
from halo_models import fit_M0_pISO

try:
    import emcee
except ImportError:
    raise ImportError("This script requires emcee: pip install emcee")

N_STEPS = 8000
N_WALKERS = 32
N_DISCARD = 2000
N_THIN = 15


def run_one_galaxy(R, Vc, err, Vbar2, seed=0):
    popt0, _ = fit_M0_pISO(R, Vc, err, Vbar2)
    chi2_M0 = np.sum(((Vc - _pISO_val(R, *popt0, Vbar2)) / err) ** 2)
    rho0_fix, rc_fix = popt0
    Rmax_data = R.max()
    Vh2_fixed = 4 * np.pi * 4.301e-6 * rho0_fix * rc_fix**2 * (
        1 - (rc_fix / R) * np.arctan(R / rc_fix))

    def log_prior(theta):
        A, Rstar = theta
        if not (0 <= A < 0.999):
            return -np.inf
        if not (0 <= Rstar < Rmax_data):
            return -np.inf
        return 0.0

    def log_likelihood(theta):
        A, Rstar = theta
        q = np.clip(1 - A * np.exp(-Rstar / np.maximum(R, 1e-3)), 0, 1)
        model = np.sqrt(np.clip(Vbar2 + q * Vh2_fixed, 0, None))
        return -0.5 * np.sum(((Vc - model) / err) ** 2)

    def log_posterior(theta):
        lp = log_prior(theta)
        if not np.isfinite(lp):
            return -np.inf
        return lp + log_likelihood(theta)

    rng = np.random.default_rng(seed)
    ndim = 2
    pos = np.column_stack([
        rng.uniform(0.01, 0.9, N_WALKERS),
        rng.uniform(0.1, Rmax_data * 0.9, N_WALKERS),
    ])

    sampler = emcee.EnsembleSampler(N_WALKERS, ndim, log_posterior)
    sampler.run_mcmc(pos, N_STEPS, progress=False)

    try:
        tau = sampler.get_autocorr_time(quiet=True)
        converged = bool(np.all(N_STEPS > 50 * tau))
    except Exception:
        tau, converged = None, False

    flat = sampler.get_chain(discard=N_DISCARD, thin=N_THIN, flat=True)
    A_s, Rstar_s = flat[:, 0], flat[:, 1]

    chi2s = []
    for A, Rstar in flat[::5]:
        q = np.clip(1 - A * np.exp(-Rstar / np.maximum(R, 1e-3)), 0, 1)
        model = np.sqrt(np.clip(Vbar2 + q * Vh2_fixed, 0, None))
        chi2s.append(np.sum(((Vc - model) / err) ** 2))
    chi2s = np.array(chi2s)

    return dict(chi2_M0=chi2_M0, tau=tau, converged=converged,
                A_median=np.median(A_s), A_ci=(np.percentile(A_s, 16), np.percentile(A_s, 84)),
                Rstar_median=np.median(Rstar_s),
                Rstar_ci=(np.percentile(Rstar_s, 16), np.percentile(Rstar_s, 84)),
                best_chi2_in_posterior=chi2s.min(),
                P_A_gt_005=np.mean(A_s > 0.05), flat_chain=flat)


def _pISO_val(R, rho0, rc, Vbar2):
    Vh2 = 4 * np.pi * 4.301e-6 * rho0 * rc**2 * (1 - (rc / R) * np.arctan(R / rc))
    return np.sqrt(np.clip(Vbar2 + Vh2, 0, None))


def run():
    loaded = load_all()
    results = {}
    for g in SPARC_OVERLAP:
        lt = loaded["lt_data"][g]
        R, Vc, err = lt["R_kpc"], lt["Vc"], lt["err_Vc"]
        Vbar2 = get_vbar2_any(g, loaded)

        res = run_one_galaxy(R, Vc, err, Vbar2)
        results[g] = res
        print(f"{g}: chi2_M0={res['chi2_M0']:.2f}  tau={res['tau']}  "
              f"converged={res['converged']}")
        print(f"  A  = {res['A_median']:.3f}  {res['A_ci']}")
        print(f"  R* = {res['Rstar_median']:.2f} kpc  {res['Rstar_ci']}")
        print(f"  best chi2 in posterior = {res['best_chi2_in_posterior']:.2f}   "
              f"P(A>0.05) = {res['P_A_gt_005']:.2f}\n")

    return results


if __name__ == "__main__":
    run()
