"""
data_loading.py

Fetches and loads the three real, public data sources used throughout
this analysis:
  1. SPARC rotation curve decompositions (Lelli, McGaugh & Schombert 2016)
  2. LITTLE THINGS kinematic tables (Iorio et al. 2017)
  3. Oh et al. (2015) mass-modelling tables (VizieR J/AJ/149/180),
     used for real total stellar (SED-fit, originally Zhang et al. 2012)
     and gas masses for the 7 galaxies without SPARC coverage.

Run this once; it populates ./sparc_data/ and ./littlethings_data/ and
returns in-memory dictionaries used by every other script in this
repository.
"""

import os
import requests
import zipfile
import io
import numpy as np
from scipy.interpolate import interp1d

TARGET_GALAXIES = ["CVnIdwA", "DDO52", "DDO87", "DDO126", "DDO154",
                    "DDO168", "DDO210", "NGC2366", "UGC8508", "WLM"]

SPARC_OVERLAP = ["DDO154", "DDO168", "NGC2366"]

# LITTLE THINGS online-table filenames use lowercase, no-space keys
LT_FILENAME_MAP = {
    "CVnIdwA": "cvidwa", "DDO52": "ddo52", "DDO87": "ddo87",
    "DDO126": "ddo126", "DDO154": "ddo154", "DDO168": "ddo168",
    "DDO210": "ddo210", "NGC2366": "ngc2366", "UGC8508": "ugc8508",
    "WLM": "wlm",
}

SPARC_URL = "https://astroweb.case.edu/SPARC/Rotmod_LTG.zip"
# Original Iorio et al. (2017) "final rotation curve" tables, linked from
# a footnote in the published paper (the authors' own hosted download,
# not a VizieR/CDS deposit -- see manuscript Data section for discussion).
LT_URL = "https://www.dropbox.com/s/t4j8dacmnwgj0yb/finalrot.zip?dl=1"


def fetch_sparc(dest="sparc_data"):
    """Download and extract the SPARC rotmod .dat files."""
    if not os.path.isdir(dest):
        r = requests.get(SPARC_URL, timeout=30)
        r.raise_for_status()
        z = zipfile.ZipFile(io.BytesIO(r.content))
        z.extractall(dest)
    return dest


def fetch_littlethings(dest="littlethings_data"):
    """Download and extract the Iorio et al. (2017) online tables."""
    if not os.path.isdir(dest):
        r = requests.get(LT_URL, timeout=30)
        r.raise_for_status()
        z = zipfile.ZipFile(io.BytesIO(r.content))
        z.extractall(dest)
    return dest


def load_sparc_galaxy(galaxy_name, sparc_dir="sparc_data"):
    """Load one galaxy's SPARC rotmod file. Returns None if not present
    in SPARC (expected for 7 of the 10 target galaxies)."""
    path = os.path.join(sparc_dir, f"{galaxy_name}_rotmod.dat")
    if not os.path.exists(path):
        return None
    data = np.loadtxt(path, comments="#")
    return {
        "R_kpc": data[:, 0], "Vobs": data[:, 1], "errV": data[:, 2],
        "Vgas": data[:, 3], "Vdisk": data[:, 4], "Vbul": data[:, 5],
        "SBdisk": data[:, 6], "SBbul": data[:, 7],
    }


def load_littlethings_galaxy(galaxy_key, lt_dir="littlethings_data"):
    """Load one galaxy's real Iorio et al. (2017) kinematic table."""
    fname = LT_FILENAME_MAP[galaxy_key]
    path = os.path.join(lt_dir, "finalrot", f"{fname}_onlinetab.txt")
    data = np.loadtxt(path, comments="#")
    return {
        "R_arcsec": data[:, 0], "R_kpc": data[:, 1],
        "Vrot": data[:, 2], "err_Vrot": data[:, 3],
        "Va": data[:, 4], "err_Va": data[:, 5],
        "Vc": data[:, 6], "err_Vc": data[:, 7],
        "sigma_v": data[:, 8], "err_sigma_v": data[:, 9],
        "Sdens": data[:, 10], "err_Sdens": data[:, 11],
    }


def load_oh2015_masses():
    """
    Fetch real total gas mass (Mgas) and SED-fit stellar mass (MstarSED,
    originally Zhang et al. 2012) for the 7 galaxies without SPARC
    coverage, from VizieR catalogue J/AJ/149/180 (Oh et al. 2015).
    Units in the source table are 1e7 Msun; returned as-is (caller
    multiplies by 1e7 when using absolute masses).
    """
    from astroquery.vizier import Vizier
    Vizier.ROW_LIMIT = -1
    cat = Vizier.get_catalogs("J/AJ/149/180/galaxies")[0]
    names_norm = [str(n).replace("_", "").replace(" ", "").upper()
                  for n in cat["Name"]]

    non_sparc = [g for g in TARGET_GALAXIES if g not in SPARC_OVERLAP]
    masses = {}
    for g in non_sparc:
        key = g.upper()
        idx = names_norm.index(key)
        row = cat[idx]
        masses[g] = {"Mgas": float(row["Mgas"]),
                      "MstarSED": float(row["MstarSED"])}
    return masses


def get_vbar2_sparc(galaxy_key, sparc_data, lt_data_entry, upsilon=0.5):
    """
    Baryonic V^2(R) for a SPARC-overlap galaxy, interpolated onto the
    real LITTLE THINGS radii. upsilon = 3.6um mass-to-light ratio
    (standard SPARC assumption, Lelli et al. 2016).
    """
    fVgas = interp1d(sparc_data["R_kpc"], sparc_data["Vgas"],
                      bounds_error=False, fill_value="extrapolate")
    fVdisk = interp1d(sparc_data["R_kpc"], sparc_data["Vdisk"],
                       bounds_error=False, fill_value="extrapolate")
    R = lt_data_entry["R_kpc"]
    Vgas_R = fVgas(R)
    Vdisk_R = fVdisk(R) * np.sqrt(upsilon)
    Vbar2 = np.sign(Vgas_R) * Vgas_R**2 + np.sign(Vdisk_R) * Vdisk_R**2
    return Vbar2


def get_vbar2_gas_shape(R, Sdens, Mgas_1e7, Mstar_1e7):
    """
    Baryonic V^2(R) for the 7 non-SPARC galaxies: real total gas and
    stellar mass (Oh et al. 2015 / Zhang et al. 2012), distributed
    according to the observed HI surface-density radial SHAPE.
    Documented, disclosed approximation -- see manuscript Data section
    and Limitations for why this is weaker than the SPARC decomposition.
    """
    R_pc = R * 1000
    integrand = 2 * np.pi * R_pc * Sdens * 1.33  # helium correction
    M_enc_shape = np.zeros_like(R)
    for i in range(1, len(R)):
        M_enc_shape[i] = M_enc_shape[i-1] + 0.5 * (
            integrand[i] + integrand[i-1]) * (R_pc[i] - R_pc[i-1])
    M_enc_shape_norm = M_enc_shape / M_enc_shape[-1]

    M_gas_enc = M_enc_shape_norm * Mgas_1e7 * 1e7
    M_star_enc = M_enc_shape_norm * Mstar_1e7 * 1e7
    G = 4.301e-6  # kpc (km/s)^2 / Msun
    return G * (M_gas_enc + M_star_enc) / np.maximum(R, 1e-3)


def load_all():
    """Convenience loader: fetches everything and returns a dict with
    lt_data, sparc_data (3 galaxies only), and oh2015_masses (7 galaxies)."""
    sparc_dir = fetch_sparc()
    lt_dir = fetch_littlethings()

    sparc_data = {g: load_sparc_galaxy(g, sparc_dir) for g in SPARC_OVERLAP}
    lt_data = {g: load_littlethings_galaxy(g, lt_dir) for g in TARGET_GALAXIES}
    oh2015_masses = load_oh2015_masses()

    return {
        "lt_data": lt_data,
        "sparc_data": sparc_data,
        "oh2015_masses": oh2015_masses,
    }


def get_vbar2_any(galaxy, loaded):
    """Dispatch: SPARC decomposition for the 3 overlap galaxies,
    gas-shape approximation for the other 7."""
    if galaxy in SPARC_OVERLAP:
        return get_vbar2_sparc(galaxy, loaded["sparc_data"][galaxy],
                                loaded["lt_data"][galaxy])
    m = loaded["oh2015_masses"][galaxy]
    lt = loaded["lt_data"][galaxy]
    return get_vbar2_gas_shape(lt["R_kpc"], lt["Sdens"],
                                m["Mgas"], m["MstarSED"])


if __name__ == "__main__":
    loaded = load_all()
    print(f"Loaded {len(loaded['lt_data'])} LITTLE THINGS galaxies")
    print(f"Loaded {len(loaded['sparc_data'])} SPARC-overlap galaxies")
    print(f"Loaded real masses for {len(loaded['oh2015_masses'])} galaxies")
