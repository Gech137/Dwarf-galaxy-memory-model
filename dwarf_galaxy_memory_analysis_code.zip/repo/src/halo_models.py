"""
halo_models.py

Equilibrium (M0) and finite-memory extension (M1) rotation-curve
models, for two independent halo families (pseudo-isothermal and NFW),
exactly as fit throughout the analysis.

M1 is always fit as a NESTED extension of M0: the halo parameters are
re-optimized jointly with the memory parameters (A, R_star), seeded
from the M0 solution, with multiple restarts. This guarantees M1
cannot fit worse than M0 in the true optimum -- an early single-start
version of this code produced a spurious violation of that guarantee,
traced to optimizer failure (a bad local minimum), not a real result.
See manuscript Section "Equilibrium versus memory model" for discussion.
"""

import numpy as np
from scipy.optimize import curve_fit

G_GRAV = 4.301e-6  # kpc (km/s)^2 / Msun


# ---------------------------------------------------------------------
# Pseudo-isothermal halo
# ---------------------------------------------------------------------

def V_pISO(R, rho0, rc, Vbar2):
    Vh2 = 4 * np.pi * G_GRAV * rho0 * rc**2 * (1 - (rc / R) * np.arctan(R / rc))
    return np.sqrt(np.clip(Vbar2 + Vh2, 0, None))


def fit_M0_pISO(R, Vc, err, Vbar2):
    def _model(R, rho0, rc):
        return V_pISO(R, rho0, rc, Vbar2)
    best = (np.inf, None)
    for rc0 in [0.1, 0.5, 1.0, 3.0, 10.0]:
        try:
            popt, _ = curve_fit(_model, R, Vc, p0=[1e8, rc0], sigma=err,
                                 maxfev=20000, bounds=([1e4, 0.01], [1e12, 100]))
            c2 = np.sum(((Vc - _model(R, *popt)) / err) ** 2)
            if c2 < best[0]:
                best = (c2, popt)
        except Exception:
            continue
    return best[1], _model  # (rho0, rc), model_fn(R, rho0, rc)


def fit_M1_pISO(R, Vc, err, Vbar2, rho0_seed, rc_seed):
    def _model(R, rho0, rc, A, Rstar):
        Vh2 = 4 * np.pi * G_GRAV * rho0 * rc**2 * (1 - (rc / R) * np.arctan(R / rc))
        q = np.clip(1 - A * np.exp(-Rstar / np.maximum(R, 1e-3)), 0, 1)
        return np.sqrt(np.clip(Vbar2 + q * Vh2, 0, None))
    best = (np.inf, None)
    for A0, Rs0 in [(0.01, 0.5), (0.1, 1), (0.3, 2), (0.5, 5)]:
        try:
            popt, _ = curve_fit(
                _model, R, Vc, p0=[rho0_seed, rc_seed, A0, Rs0], sigma=err,
                maxfev=30000,
                bounds=([1e4, 0.01, 0, 0], [1e12, 100, 0.999, 50]))
            c2 = np.sum(((Vc - _model(R, *popt)) / err) ** 2)
            if c2 < best[0]:
                best = (c2, popt)
        except Exception:
            continue
    return best[1], _model  # (rho0, rc, A, Rstar), model_fn


# ---------------------------------------------------------------------
# NFW halo
# ---------------------------------------------------------------------

def V_NFW(R, rho_s, rs, Vbar2):
    x = R / rs
    Vh2 = (4 * np.pi * G_GRAV * rho_s * rs**3 / R) * (np.log(1 + x) - x / (1 + x))
    return np.sqrt(np.clip(Vbar2 + Vh2, 0, None))


def fit_M0_NFW(R, Vc, err, Vbar2):
    def _model(R, rho_s, rs):
        return V_NFW(R, rho_s, rs, Vbar2)
    best = (np.inf, None)
    for rs0 in [0.1, 0.5, 1.0, 3.0, 10.0]:
        try:
            popt, _ = curve_fit(_model, R, Vc, p0=[1e7, rs0], sigma=err,
                                 maxfev=20000, bounds=([1e3, 0.01], [1e11, 100]))
            c2 = np.sum(((Vc - _model(R, *popt)) / err) ** 2)
            if c2 < best[0]:
                best = (c2, popt)
        except Exception:
            continue
    return best[1], _model


def fit_M1_NFW(R, Vc, err, Vbar2, rho_s_seed, rs_seed):
    def _model(R, rho_s, rs, A, Rstar):
        x = R / rs
        Vh2 = (4 * np.pi * G_GRAV * rho_s * rs**3 / R) * (np.log(1 + x) - x / (1 + x))
        q = np.clip(1 - A * np.exp(-Rstar / np.maximum(R, 1e-3)), 0, 1)
        return np.sqrt(np.clip(Vbar2 + q * Vh2, 0, None))
    best = (np.inf, None)
    for A0, Rs0 in [(0.01, 0.5), (0.1, 1), (0.3, 2), (0.5, 5)]:
        try:
            popt, _ = curve_fit(
                _model, R, Vc, p0=[rho_s_seed, rs_seed, A0, Rs0], sigma=err,
                maxfev=30000,
                bounds=([1e3, 0.01, 0, 0], [1e11, 100, 0.999, 50]))
            c2 = np.sum(((Vc - _model(R, *popt)) / err) ** 2)
            if c2 < best[0]:
                best = (c2, popt)
        except Exception:
            continue
    return best[1], _model


def aic(chi2, k):
    """AIC = chi2 + 2k (Gaussian-likelihood constant terms omitted, as
    they cancel in AIC differences between nested models)."""
    return chi2 + 2 * k
