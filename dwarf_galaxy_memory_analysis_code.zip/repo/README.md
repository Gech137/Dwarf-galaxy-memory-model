# Kinematic Coherence and Finite Dynamical Memory in Dwarf-Galaxy Rotation Curves — analysis code

This repository contains the analysis pipeline used to produce the
numerical results reported in the accompanying manuscript. It fetches
real public data at runtime (nothing is bundled or fabricated) and
reproduces every table in the paper's empirical sections.

## Provenance note

This code was reconstructed, script by script, from an interactive
analysis session (via a chat-based coding assistant) that produced
every reported number in the manuscript. It is a faithful
reconstruction of that session's logic, organized into a runnable
package — not a from-scratch reimplementation of the methodology from
the paper text alone. Where the interactive session hit a dead end
(e.g. the full 4-parameter joint MCMC posterior, which did not
converge) that is preserved honestly in the code and comments rather
than silently fixed or omitted.

## Data sources (all real, all public, fetched at runtime)

| Source | Used for | Access method |
|---|---|---|
| SPARC (Lelli, McGaugh & Schombert 2016) | Baryonic decomposition, 3 of 10 galaxies | Direct download, `astroweb.case.edu/SPARC/Rotmod_LTG.zip` |
| Iorio et al. (2017), LITTLE THINGS | Kinematic profiles, all 10 galaxies | Authors' hosted download (linked from a footnote in the published paper); see `src/data_loading.py` for the exact URL and discussion |
| Oh et al. (2015) | Real total stellar (SED-fit, orig. Zhang et al. 2012) and gas mass, 7 of 10 galaxies | VizieR catalogue `J/AJ/149/180`, via `astroquery` |

No data files are committed to this repository; `run_all.py` fetches
everything fresh on first run.

## Setup

```bash
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```

## Running

```bash
python run_all.py
```

This reproduces, in order:
1. The radial-confounding test (raw vs. partial Spearman correlation, all 10 galaxies)
2. The M0-vs-M1 AIC comparison under both halo families (all 10 galaxies)
3. Held-out radial cross-validation (DDO154, DDO168, NGC2366, WLM)
4. The dual bootstrap analysis (residual + case resampling, all 10 galaxies)
5. The converged 2D conditional MCMC posterior (DDO154, DDO168, NGC2366)

Each stage can also be run independently, e.g. `python src/aic_comparison.py`.

## Repository structure

```
├── run_all.py              # orchestrator
├── requirements.txt
├── src/
│   ├── data_loading.py     # fetches and loads all real data
│   ├── halo_models.py      # M0/M1 fitting, both halo families
│   ├── confounding_test.py
│   ├── aic_comparison.py
│   ├── cross_validation.py
│   ├── bootstrap_analysis.py
│   └── conditional_mcmc.py
└── README.md
```

## Known limitations of this code (documented, not hidden)

- The full joint 4-parameter posterior (halo + memory parameters
  sampled together) does not converge within a practical compute
  budget; only the reduced 2D conditional posterior (halo fixed) is
  reproduced as a converged result. See `src/conditional_mcmc.py`
  docstring and the manuscript's "Converged posterior" section.
- Baryonic decomposition for 7 of 10 galaxies uses real total masses
  distributed according to the observed HI surface-density *shape*
  (not an independent radial stellar profile). See
  `get_vbar2_gas_shape()` in `src/data_loading.py` and the
  manuscript's Limitations section.
- External data sources (SPARC's host, the Iorio et al. download
  link, VizieR) are outside this repository's control; if a fetch
  fails, check the URLs in `src/data_loading.py` against the current
  location of each dataset before assuming a code bug.

## Citation

If you use this code, please cite the accompanying manuscript. Data
sources retain their own citation requirements — see the manuscript's
Data and Data Availability sections.
