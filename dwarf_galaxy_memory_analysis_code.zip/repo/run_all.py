"""
run_all.py

Runs the full analysis pipeline in sequence, reproducing every table
reported in the manuscript. Run from the repository root:

    python run_all.py

Individual stages can also be run directly, e.g.:

    python src/confounding_test.py
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from confounding_test import run as run_confounding
from aic_comparison import run as run_aic
from cross_validation import run as run_cv
from bootstrap_analysis import run as run_bootstrap
from conditional_mcmc import run as run_mcmc


def main():
    print("=" * 70)
    print("1/5: Radial confounding test (raw vs. partial Spearman)")
    print("=" * 70)
    run_confounding()

    print("\n" + "=" * 70)
    print("2/5: M0 vs M1 AIC comparison (pseudo-isothermal + NFW)")
    print("=" * 70)
    run_aic()

    print("\n" + "=" * 70)
    print("3/5: Held-out radial cross-validation")
    print("=" * 70)
    run_cv()

    print("\n" + "=" * 70)
    print("4/5: Dual bootstrap analysis (residual + case resampling)")
    print("=" * 70)
    run_bootstrap()

    print("\n" + "=" * 70)
    print("5/5: Converged 2D conditional MCMC posterior")
    print("=" * 70)
    run_mcmc()


if __name__ == "__main__":
    main()
